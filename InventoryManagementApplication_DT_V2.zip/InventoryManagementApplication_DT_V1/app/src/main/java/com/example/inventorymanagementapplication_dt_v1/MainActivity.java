package com.example.inventorymanagementapplication_dt_v1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;

import java.util.ArrayList;
import java.util.List;

class FirstFragment extends Fragment{
    public FirstFragment() {
        super(R.layout.fragment_first);
    }
}

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    // SETUP TABLE FOR DATABASE
    public static class FeedReaderContract {
        // To prevent someone from accidentally instantiating the contract class,
        // make the constructor private.
        private FeedReaderContract() {}

        /* Inner class that defines the table contents */
        public static class FeedEntry implements BaseColumns {
            public static final String TABLE_NAME = "login";
            public static final String USERNAME = "username";
            public static final String PASSWORD = "password";
        }

    }

    // CREATE DATABASE FOR INVENTORY
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + MainActivity.FeedReaderContract.FeedEntry.TABLE_NAME + " (" +
                    MainActivity.FeedReaderContract.FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    MainActivity.FeedReaderContract.FeedEntry.USERNAME + " TEXT," +
                    MainActivity.FeedReaderContract.FeedEntry.PASSWORD + " TEXT)";

    // OVERRIDES CALLBACK METHODS
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + MainActivity.FeedReaderContract.FeedEntry.TABLE_NAME;
    public class FeedReaderDbHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "FeedReader.db";

        public FeedReaderDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(@NonNull SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }

        public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
        // INSTANTIATE SUBCLASS TO ACCESS DATABASE
        MainActivity.FeedReaderDbHelper dbHelper = new MainActivity.FeedReaderDbHelper(getApplicationContext());

        // Create a new map of values, where column names are the keys
        public void addValues(String title, String subcategory, String amount) {
            // Gets the data repository in write mode
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(MainActivity.FeedReaderContract.FeedEntry.USERNAME, title);
            values.put(MainActivity.FeedReaderContract.FeedEntry.PASSWORD, subcategory);
            // Insert the new row, returning the primary key value of the new row
            long newRowId = db.insert(MainActivity.FeedReaderContract.FeedEntry.TABLE_NAME, null, values);
        }

        public void defineProjection() {
            SQLiteDatabase db = dbHelper.getReadableDatabase();

            // Define a projection that specifies which columns from the database
            // you will actually use after this query.
            String[] projection = {
                    BaseColumns._ID,
                    MainActivity.FeedReaderContract.FeedEntry.USERNAME,
                    MainActivity.FeedReaderContract.FeedEntry.PASSWORD,
            };

            // Filter results WHERE "title" = 'My Title'
            String selection = MainActivity.FeedReaderContract.FeedEntry.USERNAME + " = ?";
            String[] selectionArgs = {"My Title"};

            // How you want the results sorted in the resulting Cursor
            String sortOrder =
                    MainActivity.FeedReaderContract.FeedEntry.PASSWORD + " DESC";

            Cursor cursor = db.query(
                    MainActivity.FeedReaderContract.FeedEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    sortOrder               // The sort order
            );
            List<Object> itemIds = new ArrayList<>();
            while (cursor.moveToNext()) {
                long itemId = cursor.getLong(
                        cursor.getColumnIndexOrThrow(MainActivity.FeedReaderContract.FeedEntry._ID));
                itemIds.add(itemId);
            }
            cursor.close();
        }

        public void deleteItem() {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            // Define 'where' part of query.
            String selection = MainActivity.FeedReaderContract.FeedEntry.USERNAME + " LIKE ?";
            // Specify arguments in placeholder order.
            String[] selectionArgs = {"MyTitle"};
            // Issue SQL statement.
            int deletedRows = db.delete(MainActivity.FeedReaderContract.FeedEntry.TABLE_NAME, selection, selectionArgs);
        }

        public void updateItem() {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // New value for one column
            String item = "MyNewTitle";
            ContentValues values = new ContentValues();
            values.put(MainActivity.FeedReaderContract.FeedEntry.USERNAME, item);

            // Which row to update, based on the title
            String selection = MainActivity.FeedReaderContract.FeedEntry.USERNAME + " LIKE ?";
            String[] selectionArgs = {"MyOldTitle"};

            int count = db.update(
                    MainActivity.FeedReaderDbHelper.DATABASE_NAME,
                    values,
                    selection,
                    selectionArgs);
        }
        public void loginButtonPress(View view) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            EditText editText = (EditText) findViewById(R.id.enter_username);
            String username = String.valueOf(findViewById(R.id.enter_username));
            Button button = (Button) findViewById(R.id.login_button);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Log.d("BUTTONS", "User tapped the login button");
                    if (username == null) {
                        editText.setText("Enter your username");
                    }
                    else {
                        startActivity(new Intent(MainActivity.this, Inventory_management.class));
                    }
                }
            });
        }
    }

}