package com.example.inventorymanagementapplication_dt_v1;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import static java.nio.file.Files.delete;

import androidx.appcompat.app.AppCompatActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.view.Menu;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;


import com.google.android.material.internal.MaterialCheckable;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

class SecondFragment extends Fragment {
    public SecondFragment() {
        super(R.layout.fragment_second);
    }

}
public class Inventory_management extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_management);

        Toolbar inventoryToolbar = (Toolbar) findViewById(R.id.inventory_toolbar);
        setSupportActionBar(inventoryToolbar);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        TableLayout tableLayout = (TableLayout) findViewById(R.id.Inventory_Layout);
        // Attempt to make view not editable until edit is pressed. // Not working....
            //tableLayout.setEnabled(false);
            //tableLayout.setClickable(false);
            //tableLayout.setFocusableInTouchMode(false);
            //tableLayout.setFocusable(false);

        // Stretch columns to make it look a little nicer.
        tableLayout.setStretchAllColumns(true);
        // Create a checkbox with each new row for deleting purposes.
        CheckBox checkBox = new CheckBox(this);
        // Create new table row
        TableRow tableRow = new TableRow(this);

        if (id == R.id.action_add) {
            // User chooses the "add" item.
            tableRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            // First column
            EditText name = new EditText(this);
            name.setText("Name");
            // Second column
            EditText subcategory = new EditText(this);
            subcategory.setText("Subcategory");
            //Third column
            EditText amount = new EditText(this);
            amount.setText("Amount");
            // Add views to row
            tableRow.addView(name);
            tableRow.addView(subcategory);
            tableRow.addView(amount);
            tableRow.addView(checkBox);
            // Add row to layout
            tableLayout.addView(tableRow, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT));

        }

        else if(id == R.id.action_delete) {
        // If the delete button is pressed.


        }

        else if (id == R.id.action_edit) {
            // Useless to do this if table is already editable...
            return true;
        }
        else {
            // The user's action isn't recognized.
            // Invoke the superclass to handle it.
            return super.onOptionsItemSelected(item);
        }
        return false;
    }



    // SETUP TABLE FOR DATABASE
    public static class FeedReaderContract {
        // To prevent someone from accidentally instantiating the contract class,
        // make the constructor private.
        private FeedReaderContract() {}

        /* Inner class that defines the table contents */
        public static class FeedEntry implements BaseColumns {
            public static final String TABLE_NAME = "inventory";
            public static final String COLUMN_NAME_ITEM = "item";
            public static final String COLUMN_NAME_SUBCATEGORY = "subcategory";
            public static final String COLUMN_NAME_AMOUNT = "amount";
        }

    }

    // CREATE DATABASE FOR INVENTORY
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + FeedReaderContract.FeedEntry.TABLE_NAME + " (" +
                    FeedReaderContract.FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM + " TEXT," +
                    FeedReaderContract.FeedEntry.COLUMN_NAME_SUBCATEGORY + " TEXT," +
                    FeedReaderContract.FeedEntry.COLUMN_NAME_AMOUNT + " TEXT)";

    // OVERRIDES CALLBACK METHODS
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + FeedReaderContract.FeedEntry.TABLE_NAME;
    public class FeedReaderDbHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "FeedReader.db";

        public FeedReaderDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(@NonNull SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }

        public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
        // INSTANTIATE SUSBCLASS TO ACCESS DATABASE
        FeedReaderDbHelper dbHelper = new FeedReaderDbHelper(getApplicationContext());




        // Create a new map of values, where column names are the keys
        public void addValues(String title, String subcategory, String amount) {
            // Gets the data repository in write mode
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM, title);
            values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_SUBCATEGORY, subcategory);
            values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_AMOUNT, amount);

            // Insert the new row, returning the primary key value of the new row
            long newRowId = db.insert(FeedReaderContract.FeedEntry.TABLE_NAME, null, values);
        }

        public void defineProjection() {
            SQLiteDatabase db = dbHelper.getReadableDatabase();

            // Define a projection that specifies which columns from the database
            // you will actually use after this query.
            String[] projection = {
                    BaseColumns._ID,
                    FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM,
                    FeedReaderContract.FeedEntry.COLUMN_NAME_SUBCATEGORY,
                    FeedReaderContract.FeedEntry.COLUMN_NAME_AMOUNT,
            };

            // Filter results WHERE "title" = 'My Title'
            String selection = FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM + " = ?";
            String[] selectionArgs = {"My Title"};

            // How you want the results sorted in the resulting Cursor
            String sortOrder =
                    FeedReaderContract.FeedEntry.COLUMN_NAME_SUBCATEGORY + " DESC";

            Cursor cursor = db.query(
                    FeedReaderContract.FeedEntry.TABLE_NAME,   // The table to query
                    projection,             // The array of columns to return (pass null to get all)
                    selection,              // The columns for the WHERE clause
                    selectionArgs,          // The values for the WHERE clause
                    null,                   // don't group the rows
                    null,                   // don't filter by row groups
                    sortOrder               // The sort order
            );
            List<Object> itemIds = new ArrayList<>();
            while (cursor.moveToNext()) {
                long itemId = cursor.getLong(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));
                itemIds.add(itemId);
            }
            cursor.close();
        }

        public void deleteItem() {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            // Define 'where' part of query.
            String selection = FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM + " LIKE ?";
            // Specify arguments in placeholder order.
            String[] selectionArgs = {"MyTitle"};
            // Issue SQL statement.
            int deletedRows = db.delete(FeedReaderContract.FeedEntry.TABLE_NAME, selection, selectionArgs);
        }

        public void updateItem() {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // New value for one column
            String item = "MyNewTitle";
            ContentValues values = new ContentValues();
            values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM, item);

            // Which row to update, based on the title
            String selection = FeedReaderContract.FeedEntry.COLUMN_NAME_ITEM + " LIKE ?";
            String[] selectionArgs = {"MyOldTitle"};

            int count = db.update(
                    FeedReaderDbHelper.DATABASE_NAME,
                    values,
                    selection,
                    selectionArgs);
        }
    }
    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return super.onCreateOptionsMenu(menu);
    }

}